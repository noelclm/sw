function cambiarCSS(archivo) {
    document.getElementById('estilo').setAttribute('href',archivo);
}